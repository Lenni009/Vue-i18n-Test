export default {
	hello: 'Hallo Welt',
}