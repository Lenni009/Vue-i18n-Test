import helloWorld from "./hello-world";

export default {
	helloWorld
}