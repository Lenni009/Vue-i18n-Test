export default {
	hello: 'Hello World',
}